package com.capgemini.lab5;

import java.util.Scanner;

class NameException extends Exception {

	private String message;
	
	public NameException() {
		
	}
	
	public NameException(String message) {
		this.message=message;
	}
	
	public String getMessage() {
		return this.message;
	}
}




public class Exercise2 {

	private static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		Exercise2 nt = new Exercise2();
		try {
			
		System.out.println("Enter first name");
		String firstName=scanner.nextLine();
		System.out.println("Enter last name");
		String lastName=scanner.nextLine();
		
		if(firstName.equals("") && lastName.equals("")) {
		  throw new NameException("First name and last name can not be blank");
		}else {
			System.out.println(firstName+" "+lastName);
		}
		}catch(NameException e){
			//nt.getMessage();
			e.printStackTrace();
			System.out.println("First name and last name can not be blank");
		}
		
	}

}
