package com.capgemini.lab5;


import java.util.Scanner;

class EmployeeException extends Exception {
	private String message;

	public EmployeeException() {

	}

	public EmployeeException(String message) {
		this.message=message;
	}

	public String getMessage() {
		return this.message;
	}


}




public class Exercise3 {
	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		try {
			System.out.println("Enter Salary of Employee: ");
			int salary= scanner.nextInt();
			if(salary<3000) {
				throw new EmployeeException("Employee salary less than 3000");
			}
			System.out.println("Employee salary above 3000");

		}catch(EmployeeException e) {
			e.printStackTrace();
		}

	}

}
