package com.capgemini.lab1;

import java.util.Scanner;

public class Exercise7 {
	private static Scanner sc=new Scanner(System.in);
	public static boolean checkNumber(int num) {
		boolean flag=false; 
		int c=0; 
		while(num>0) {  
			if(c>=num%10) { 
				flag=true;
				break;
			}
			else { 
				flag=false; 
				//return flag;
			}
			c=num%10;
			num=num/10;
		}
		return flag;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number");
		int n=sc.nextInt();
		boolean flag1=checkNumber(n);
		if(flag1==true) {
			System.out.println("The digits of the number is in increasing order");
		}
		else {
			System.out.println("The digits of the number are not in increasing order");
		}
	}

}
