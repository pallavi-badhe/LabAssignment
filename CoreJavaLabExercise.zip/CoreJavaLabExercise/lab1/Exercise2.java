package com.capgemini.lab1;

import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    String value = sc.nextLine();
	   
	    switch (value) {

	      case "Red":
	       System.out.println("Stop");
	        break;

	      case "Yellow":
	    	  System.out.println("Stop");
		        break;

	      case "Green":
	    	  System.out.println("Go");
		        break;
	    }
	  }

}
