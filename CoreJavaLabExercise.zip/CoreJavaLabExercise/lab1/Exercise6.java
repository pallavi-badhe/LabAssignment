package com.capgemini.lab1;

import java.util.Scanner;

public class Exercise6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number :");
		int n=sc.nextInt();
		calculateDifference(n);

	}

	public static void calculateDifference(int n) {
		int f=0,s=0;
		for(int i=0;i<=n;i++) {
			f=f+(i*i);
			s=s+i;
		}
		s=s*s;
		int diff=f-s;
		System.out.println("The Difference is "+diff);
	}

}
