package com.capgemini.lab6;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise2 {
	private static Scanner sc=new Scanner(System.in);
	  public static void main(String args[]) {
		  
		System.out.println("Enter the String: ");
		String str=sc.nextLine();
		char arr[]=str.toCharArray();
		HashMap<Character,Integer> outputMap=countChars(arr);
		System.out.println(outputMap);
		
	}
	  
	  
	  private static HashMap<Character,Integer>countChars(char[] arr){
		  HashMap<Character,Integer>hm=new HashMap<>();
		  for (char c : arr)
	      {
	          if(hm.containsKey(c))
	          {
	                 hm.put(c, hm.get(c)+1);
	          }
	          else
	          {
	               hm.put(c, 1);
	          }
	      }
	    
	     return hm;
	  }

}
