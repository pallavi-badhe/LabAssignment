package com.capgemini.lab6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Exercise6 {

	private static Scanner sc=new Scanner(System.in);
	   
	public static void main(String args[]) {
		int j;
		HashMap<Integer,Integer> voter=new HashMap<Integer,Integer>();
		System.out.println("Enter no of person you want to insert:");
		int no=Integer.parseInt(sc.nextLine());
		for (int i=0;i<no;i++) {
	 System.out.println("Enter id of person: ");
	 int id=Integer.parseInt(sc.nextLine());
	 System.out.println("Enter age of person:");
	 int age=Integer.parseInt(sc.nextLine());
	 voter.put(id, age);
		}
		List<Integer>output=voterList(voter);
		for(int i:output)
		{
			System.out.println("Person with valid age:"+"id= "+i);
		}
		
		
	}
	
	public static List<Integer>voterList(HashMap<Integer,Integer>hm){
		List <Integer>list1=new ArrayList<Integer>();
		for(Map.Entry<Integer, Integer> entry:hm.entrySet()) {
			if(entry.getValue()>18) {
				int i=entry.getKey();
				
				list1.add(i);
			
			}
		}
		return list1;
		
		
	
		
	}
}
