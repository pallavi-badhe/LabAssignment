package com.capgemini.lab6;


import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Exercise1 {

		public static void main(String[] args) {
			
			 HashMap<String, Integer> hm = new HashMap<String, Integer>(); 
			
		        hm.put("DS", 83); 
		        hm.put("Java", 75); 
		        hm.put("C++", 89); 
		        hm.put("DBMS", 90); 
		      
		       List<Integer> outputList = sortByValue(hm); 
		       System.out.println("Sorted list:" + outputList);
	   	}

		public static List<Integer> sortByValue(HashMap<String, Integer> hm) 

	    { 
	        List list = new LinkedList(hm.entrySet()); 
	        System.out.println(list);
	        Collections.sort(list, new Sortbyval()) ; 
	     
	       List result = new LinkedList(); 
	       Iterator i=list.iterator();
	       while(i.hasNext())
	       {
	    	   Map.Entry map=( Map.Entry )i.next();
	          result.add( map.getValue()); 

	        } 

	        return result; 

	    } 

	}
	
	
	
