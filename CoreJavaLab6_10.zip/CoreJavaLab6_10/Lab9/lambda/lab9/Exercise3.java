package com.capgemini.lab9;
@FunctionalInterface
interface ValidateInterface{
	boolean validateName(String name,String password);
}

public class Exercise3 {

	public static void main(String[] args) {
		ValidateInterface v=(name,password)->{
			if(name.equals("Pallavi") && password.equals("abc123")) {
				return true;
			}
			return false;

		};
		System.out.println(v.validateName("Pallavi", "abc123"));
	}

}
