package com.capgemini.lab9;
@FunctionalInterface
interface Inter{
	String space(String str);

}

public class Exercise2 {

	public static void main(String[] args) {
		Inter itr=(str)->{
			String[] s=str.split("");
			String spcString="";
			for(String string : s) {
				spcString +=string + " ";
			}
			return spcString;
		};
		System.out.println(itr.space("CG"));
	}

}
