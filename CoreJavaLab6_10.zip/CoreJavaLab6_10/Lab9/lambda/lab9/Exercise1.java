package com.capgemini.lab9;
@FunctionalInterface
interface Arithmetic{
	public abstract double PowOfNumber(double x,double y);
}



public class Exercise1{
	public static void main(String args[])
	{
		Arithmetic m=(x,y)->Math.pow(2,3) ;
		System.out.println(m.PowOfNumber(2,3));
	}

}
