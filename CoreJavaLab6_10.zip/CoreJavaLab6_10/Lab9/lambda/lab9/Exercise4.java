package com.capgemini.lab9;
@FunctionalInterface
interface Student{
	Girl getName(String name);
}

class Girl
{
	private String name;
	Girl()
	{
		
	}
	Girl(String name)
	{
		this.name=name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Name=" + name;
	}
	
	
}
public abstract class Exercise4 implements Student {
	public static void main(String[] args) {
	Student s= Girl :: new;
		//Girl g=new Girl()
//Student s=(name)->getName("Pallavi");
System.out.println(s.getName("Pallavi"));
}
}




