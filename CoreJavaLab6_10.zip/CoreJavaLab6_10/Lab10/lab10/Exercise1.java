package com.capgemini.lab10;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

class Exercise1
{
            public static void main(String args[])throws IOException
            {
                        int a=1;
                        char ch;
                        
                        FileInputStream f=new FileInputStream("C:\\Users\\Admin\\Desktop\\Sample.txt");
                        System.out.println("Contents of the file are");
                        int n=f.available();
                        System.out.print(a+": ");
                        for(int i=0;i<n;i++)
                        {
                                    ch=(char)f.read();
                                    System.out.print(ch);
                                    if(ch=='\n')
                                    {
                                                System.out.print(++a+": ");
                                               
                                    }
                                               
                        }
            }
}
